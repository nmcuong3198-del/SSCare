import "./Header.css";
import Button from "../Common/Button/Button";
import logo from "../../assets/logo/logo.jpg";
import { useNavigate } from "react-router-dom";

const navigate = useNavigate();

export default function Header() {
  return (
    <header className="header">
      <div className="container header-container">

        <div className="logo">
          <img src={logo} alt="SSCare Logo" />
          <h1>SSCare</h1>
        </div>

        <nav>
          <ul className="nav-menu">
            <li><a href="#">Trang chủ</a></li>
            <li><a href="#mission">Về chúng tôi</a></li>
            <li><a href="#download">Tải ứng dụng</a></li>
          </ul>
        </nav>

        <Button onClick={() => navigate("/login")}>
          Đăng nhập
      </Button>

      </div>
    </header>
  );
}