import Home from "./pages/Landing/Home";
import "./styles/global.css";

function App() {
    return <Home />;
}

export default App;